<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Chatbot | Gift Of Life Portal</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>body {
    background-image: url('images/1.jpg'); /* Replace 'wondered.jpg' with your image path */
    background-size: cover;
    background-position: center;
    /* Additional styles */
    /* ... */
}
</style></head>
<body>
    <div class="container mt-5">
        <div class="card" style="max-width: 400px; margin: 0 auto;">
            <div class="card-header">
                <h5 class="card-title">GOLP Online Chatbot</h5>
            </div>
            <div class="card-body" id="chatbox">
                <div class="media mb-3">
                    <i class="fas fa-robot fa-2x mr-3"></i>
                    <div class="media-body bg-light rounded p-2">
                        <p class="mb-0">Hello there, how can I help you?</p>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="input-group">
                    <input id="data" type="text" class="form-control" placeholder="Type something here.." required>
                    <div class="input-group-append">
                        <button id="send-btn" class="btn btn-primary">Send</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-3" style="max-width: 400px; margin: 0 auto;">
        <a href="contact.php" class="btn btn-danger btn-block">Contact Us</a>
    </div>
<!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#send-btn").on("click", function(){
                var value = $("#data").val();
                appendUserMessage(value);
                sendMessage(value);
            });

            $("#data").on("keypress", function(event) {
                if (event.which === 13) { // "Enter" key pressed
                    var value = $("#data").val();
                    appendUserMessage(value);
                    sendMessage(value);
                }
            });

            function appendUserMessage(message) {
                var userMsg = `
                    <div class="media mb-3 justify-content-end">
                        <div class="media-body bg-primary text-white rounded p-2">
                            <p class="mb-0">${message}</p>
                        </div>
                        <i class="fas fa-user fa-2x ml-3"></i>
                    </div>
                `;
                $("#chatbox").append(userMsg);
                $("#data").val('');
            }

            function sendMessage(message) {
                $.ajax({
                    url: 'message.php',
                    type: 'POST',
                    data: 'text=' + message,
                    success: function(result){
                        var botReply = `
                            <div class="media mb-3">
                                <i class="fas fa-robot fa-2x mr-3"></i>
                                <div class="media-body bg-light rounded p-2">
                                    <p class="mb-0">${result}</p>
                                </div>
                            </div>
                        `;
                        $("#chatbox").append(botReply);
                        $("#data").val('');
                        $(".card-body").scrollTop($(".card-body")[0].scrollHeight);
                    }
                });
            }
            $("#contactBtn").on("click", function() {
                window.location.href = "contact.php";
            });
        });
    </script>
</body>
</html>
