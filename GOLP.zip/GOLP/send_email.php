<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$referrerName = $_POST['referrer_name']; // Assuming you capture the referrer's name in your form
$friendName = $_POST['friend_name'];
$friendEmail = $_POST['friend_email'];
$yourEmail = 'giftoflifeportal@gmail.com'; // Replace with your Gmail address
$yourPassword = 'wkgm nbhs idfy mgoi'; // Replace with your Gmail password or app password if 2FA is enabled

$mail = new PHPMailer(true);

try {
    // SMTP Configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $yourEmail;
    $mail->Password = $yourPassword;
    $mail->SMTPSecure = 'tls'; // TLS or SSL
    $mail->Port = 587; // TLS: 587, SSL: 465

    // Email Content
    $mail->setFrom($yourEmail, 'Gift of Life Portal');
    $mail->addAddress($friendEmail, $friendName);
    $mail->Subject = 'Join the Gift of Life Portal and Donate Blood!';
    
    // Message including both referrer's and friend's names and a website link
    $message = "Hi $friendName,\n\nI hope this message finds you well! Your friend, $referrerName, has referred you to join the Gift of Life Portal. This platform is dedicated to blood donation and helping people around us. Your contribution can save lives and make a significant impact. Sign up now to donate blood and support a noble cause!\n\nClick here to visit the Gift of Life Portal: https://www.giftoflifeportal.com\n\nBest regards,\nGift of Life Portal";
    
    $mail->Body = $message;

    $mail->send();

    // Display success message after sending email
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Email Sent Successfully</title>
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <style>
        /* Additional CSS styles */
        /* Add your custom styles here */
        body {
          background-color: #f8f9fa;
          font-family: Arial, sans-serif;
        }
        .success-container {
          max-width: 600px;
          margin: 100px auto;
          padding: 20px;
          border-radius: 8px;
          background-color: #fff;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          text-align: center;
        }
        h1 {
          color: #4CAF50;
        }
        .redirect-message {
          margin-top: 20px;
          font-size: 18px;
        }
        .countdown {
          font-size: 24px;
          font-weight: bold;
        }
      </style>
    </head>
    <body>
    
    <div class="container">
      <div class="success-container">
        <h1>Email Sent Successfully <span class="tick-symbol">&#10004;</span></h1>
        <p class="redirect-message">Redirecting back to the previous page in <span id="countdown">5</span> seconds...</p>
      </div>
    </div>
    
    <!-- JavaScript for countdown and redirection -->
    <script>
      let countdown = 3; // Countdown duration in seconds
      let countdownElement = document.getElementById(\'countdown\');
      
      // Function to update countdown
      function updateCountdown() {
        countdown--;
        countdownElement.innerText = countdown;
        if (countdown === 0) {
          window.history.back(); // Redirect to the previous page after countdown
        } else {
          setTimeout(updateCountdown, 1000); // Update countdown every second
        }
      }
      
      // Start countdown
      updateCountdown();
    </script>
    
    </body>
    </html>';
} catch (Exception $e) {
    echo 'Email sending failed. Error: ' . $mail->ErrorInfo;
}
?>
