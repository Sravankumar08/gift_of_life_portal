<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Refer a Friend</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    /* Additional CSS styles */
    /* Add your custom styles here */
    body {
    background-image: url('admin/img/banner.png'); /* Replace 'wondered.jpg' with your image path */
    background-size: cover;
    background-position: center;
    /* Additional styles */
    /* ... */
}
    .nowrap {
      white-space: nowrap;
    }
  </style>
</head>
<body>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
          <h2 class="card-title mb-4">Refer a Friend to Gift of Life <span class="nowrap">Portal</span></h2>
          <form id="referForm" method="post" action="send_email.php">
            <div class="form-group">
              <label for="referrerName">Your Name</label>
              <input type="text" class="form-control" id="referrerName" name="referrer_name" required>
            </div>
            <div class="form-group">
              <label for="friendName">Friend's Name</label>
              <input type="text" class="form-control" id="friendName" name="friend_name" required>
            </div>
            <div class="form-group">
              <label for="friendEmail">Friend's Email</label>
              <input type="email" class="form-control" id="friendEmail" name="friend_email" required>
            </div>
            <button type="submit" class="btn btn-primary">Refer Friend</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
  // Client-side form validation using JavaScript
  document.getElementById('referForm').addEventListener('submit', function(event) {
    const referrerName = document.getElementById('referrerName').value.trim();
    const friendName = document.getElementById('friendName').value.trim();
    const friendEmail = document.getElementById('friendEmail').value.trim();

    if (referrerName === '' || friendName === '' || friendEmail === '') {
      alert('Please fill in all fields.');
      event.preventDefault();
    }
  });
</script>

</body>
</html>