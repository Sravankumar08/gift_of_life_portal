<?php
error_reporting(0);
include('includes/config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = 1;
    $bloodGroup = $_POST['bloodGroup'];
    $offset = $_POST['offset'];

    $sql = "SELECT * FROM tblblooddonars WHERE status=:status AND BloodGroup=:bloodGroup LIMIT $offset, 10";
    $query = $dbh->prepare($sql);
    $query->bindParam(':status', $status, PDO::PARAM_STR);
    $query->bindParam(':bloodGroup', $bloodGroup, PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);

    foreach ($results as $result) {
        ?>
        <div class="col-md-4 pricing">
            <div class="price-top">
                <img src="images/blood-donor.jpg" alt="Blood Donor" style="border:1px #000 solid"
                    class="img-fluid" />
                <h3><?php echo htmlentities($result->FullName); ?></h3>
            </div>
            <div class="price-bottom p-4">
                <!-- Display donor information -->
                <!-- ... (previous code) ... -->
                <a class="btn btn-primary" style="color:#fff"
                    href="contact-blood.php?cid=<?php echo $result->id; ?>">Request</a>
            </div>
        </div><br>
        <?php
    }
}
?>
