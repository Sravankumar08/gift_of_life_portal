from flask import Flask, render_template
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import base64
from io import BytesIO

app = Flask(__name__)

def generate_plot():
    # Sample data (replace this with your actual dataset)
    data = pd.read_csv('ml_dataset.csv')
    # data['Date'] = pd.to_datetime(data['Date'])

    X = data[['Year']]
    y = data['collected_blood_units']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    mse = mean_squared_error(y_test, y_pred)
    print(f'Mean Squared Error: {mse}')

    # Plot actual vs predicted values
    plt.fill_between(X_test['Year'], y_test, color='black', alpha=0.3, label='Actual Demand')

    # Generate new data for prediction
    new_data = pd.DataFrame({'Year': [2023, 2024]})

    # Make predictions on the new data
    new_predictions = model.predict(new_data)
    # Plot the predicted values as an area plot
    plt.fill_between(new_data['Year'], new_predictions, color='blue', alpha=0.3, label='Forecasted Demand')

    #plt.figure(figsize=(9, 6))  # Adjust the figure size accordingly
    plt.xlabel('Year')
    plt.ylabel('Demand')
    plt.title('Blood Demand Forecasting with Regression')
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True)

    # Convert the plot to a base64 encoded string
    img_buf = BytesIO()
    plt.savefig(img_buf, format='png')
    img_buf.seek(0)
    img_str = base64.b64encode(img_buf.read()).decode('utf-8')
    plt.close()

    return img_str

@app.route('/')
def index():
    # Generate the plot
    img_str = generate_plot()

    # Return the HTML template with the plot embedded
    return render_template('index.html', img_data=img_str)

if __name__ == '__main__':
    app.run(debug=True)
