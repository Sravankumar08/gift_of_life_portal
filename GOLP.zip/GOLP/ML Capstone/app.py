from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predicting', methods=['POST'])
def predicting():
    age = int(request.form['age'])
    bgrp = request.form['bgrp']
    res='INVALID'
    import pandas as pd
    from sklearn.model_selection import train_test_split
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import accuracy_score, classification_report

    # Load the dataset
    dataset_path = 'blood_donors.csv'
    df = pd.read_csv(dataset_path)

    # Convert blood group to numerical values using one-hot encoding
    df['blood_group'] = df['blood_group'].astype(str)

    # Get unique values in the 'blood_group' column
    unique_blood_groups = df['blood_group'].unique()

    # Create dummy columns for each unique blood group
    for blood_group in unique_blood_groups:
        column_name = f'blood_group_{blood_group}'
        df[column_name] = df['blood_group'].apply(lambda x: 1 if blood_group in x else 0)

    # Use only 'age' and one-hot encoded 'blood_group' columns as features
    X = df[['Age'] + [f'blood_group_{blood_group}' for blood_group in unique_blood_groups]]

    # Split the data into features (X) and target variable (y)
    X = df[['Age','blood_group_A+','blood_group_A-','blood_group_B+','blood_group_B-','blood_group_O+','blood_group_O-','blood_group_AB+','blood_group_AB-']].values
    y = df['willingness_to_donate']
    
    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create a Random Forest classifier
    clf = RandomForestClassifier(random_state=42)

    # Train the classifier
    clf.fit(X_train, y_train)

    # Make predictions on the test set
    y_pred = clf.predict(X_test)

    # Evaluate the model
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)

    #print(f'Accuracy: {accuracy}')
    #print('Classification Report:\n', report)
    s=set(['A+','A-','B+','B-','O+','O-','AB+','AB-'])
    bld='Blood Group_'
    s.remove(bgrp)
    b=bld+bgrp
    l=[]
    for i in s:
        l.append(bld+i)
    # Example prediction for a new data point
    new_data = pd.DataFrame({'age': [age],b : [1], l[0] : [0],l[1] : [0],l[2] : [0],l[3] : [0],l[4] : [0],l[5] : [0],l[6] : [0]})
    prediction = clf.predict(new_data)
    if prediction:
        res='YES'
    else:
        res='MAY BE NOT'


    return render_template('result.html', age=age,bgrp=bgrp,res=res)

if __name__ == '__main__':
    app.run(debug=True)
