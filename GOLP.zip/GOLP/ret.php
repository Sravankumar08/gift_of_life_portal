<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Blood Donor Pie Chart</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Link Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
  <style>
    body {
    background-image: url('images/banner3.jpg'); /* Replace 'wondered.jpg' with your image path */
    background-size: cover;
    background-position: center;
    /* Additional styles */
    /* ... */
}
    /* Additional CSS styles */
    .chart-container {
      width: 400px;
      height: 400px;
      margin: auto;
    }
    .chart-card {
      margin-top: 50px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card chart-card">
          <div class="card-body">
            <h5 class="card-title text-center">Blood Donor Pie Chart</h5>
            <div class="chart-container">
              <canvas id="donorChart"></canvas>
            </div>
            <div class="text-center mt-3">
              <button class="btn btn-primary" onclick="redirectToIndex()">Go to Home</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php
  // Establish database connection and retrieve data from the database
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "bbdms";

  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT BloodGroup, COUNT(*) as count FROM tblblooddonars GROUP BY BloodGroup";
  $result = $conn->query($sql);

  $labels = [];
  $data = [];

  if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
          $labels[] = $row['BloodGroup'];
          $data[] = $row['count'];
      }
  }

  $conn->close();
  ?>

  <script>
    // Get data from PHP
    var labels = <?php echo json_encode($labels); ?>;
    var data = <?php echo json_encode($data); ?>;
    
    var ctx = document.getElementById('donorChart').getContext('2d');
    var donorChart = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: labels,
        datasets: [{
          label: 'Blood Donors by Type',
          data: data,
          backgroundColor: [
            'rgba(255, 99, 132, 0.6)',
            'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        // Customize options as needed
      }
    });

    // Function to redirect to the index page
    function redirectToIndex() {
      window.location.href = 'index.php'; // Replace 'index.php' with your desired page
    }
  </script>
</body>
</html>
