<?php
error_reporting(0);
include('includes/config.php');
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Gift Of Life Portal | Blood Donor List </title>
    <!-- Meta tag Keywords -->

    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!--// Meta tag Keywords -->

    <!-- Custom-Files -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <!-- Style-CSS -->
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <!-- Font-Awesome-Icons-CSS -->
    <!-- //Custom-Files -->

    <!-- Web-Fonts -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
        rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
        rel="stylesheet">
    <!-- //Web-Fonts -->
	<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
	<script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>


</head>

<body>
    <?php include('includes/header.php');?>

    <!-- banner 2 -->
    <div class="inner-banner-w3ls">
        <div class="container">

        </div>
        <!-- //banner 2 -->
    </div>
    <!-- page details -->
    <div class="breadcrumb-agile">
        <div aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Blood Donor List</li>
            </ol>
        </div>
    </div>
    <!-- //page details -->

    <!-- contact -->
    <div class="agileits-contact py-5">
        <div class="py-xl-5 py-lg-3">

            <div class="w3ls-titles text-center mb-5">
                <h3 class="title">Blood Donor List</h3>
                <span>
                    <i class="fas fa-user-md"></i>
                </span>
                <p class="mt-2">"Quenching Thirsts, Sparking Hope: A Symphony of Selfless Hearts—Our Blood Donors"</p>
            </div>

            <?php
    if(isset($_SESSION['login'])){
    $status = 1;
    $sql = "SELECT DISTINCT BloodGroup FROM tblblooddonars WHERE status=:status";
    $query = $dbh->prepare($sql);
    $query->bindParam(':status', $status, PDO::PARAM_STR);
    $query->execute();
    $bloodGroups = $query->fetchAll(PDO::FETCH_COLUMN);

    foreach ($bloodGroups as $bloodGroup) {
        ?>
        <div class="d-flex">
            <div class="row package-grids mt-5" style="padding-left: 50px;">
                <h3><?php echo $bloodGroup; ?> Donors</h3>

                <?php
                $sql = "SELECT * FROM tblblooddonars WHERE status=:status AND BloodGroup=:bloodGroup";
                $query = $dbh->prepare($sql);
                $query->bindParam(':status', $status, PDO::PARAM_STR);
                $query->bindParam(':bloodGroup', $bloodGroup, PDO::PARAM_STR);
                $query->execute();
                $results = $query->fetchAll(PDO::FETCH_OBJ);

                $cnt = 1;
                foreach ($results as $result) {
                    ?>
                    <div class="col-md-4 pricing">
                        <div class="price-top">
                            <img src="images/blood-donor.jpg" alt="Blood Donor" style="border:1px #000 solid"
                                class="img-fluid" />
                            <h3><?php echo htmlentities($result->FullName); ?></h3>
                        </div>
                        <div class="price-bottom p-4">
                            <!-- Display donor information -->
                            <!-- ... (previous code) ... -->
                            <a class="btn btn-primary" style="color:#fff"
                                href="contact-blood.php?cid=<?php echo $result->id; ?>">Request</a>
                        </div>
                    </div><br>
                    <?php
                    if ($cnt++ >= 2) {
                        break; // Display only two donors initially
                    }
                }
                ?>

                <?php if ($query->rowCount() > 2) { ?>
                    <button class="btn btn-secondary mt-3 more-btn" data-group="<?php echo $bloodGroup; ?>"
                        data-offset="2">More</button>
                    <div class="extraDonors_<?php echo $bloodGroup; ?>" style="display: none;">
                        <!-- Additional donors will be loaded here via AJAX -->
                    </div>

                    <script>
    $(document).ready(function () {
        $(".more-btn").click(function () {
            var bloodGroup = $(this).data("group");

            $.ajax({
                type: "POST",
                url: "load-more-donors.php", // Replace with the actual file to handle AJAX requests
                data: {
                    bloodGroup: bloodGroup,
                    offset: $(".extraDonors_" + bloodGroup + " .pricing").length // Use the count of displayed donors as the offset
                },
                success: function (response) {
                    $(".extraDonors_" + bloodGroup).append(response); // Append new donors to the existing list
                    $(".extraDonors_" + bloodGroup).toggle();
                }
            });
        });
    });
</script>

                <?php } ?>
            </div>
        </div>
    <?php }}
    else{
        ?>
        <div class="w3ls-titles text-center mb-5">
        <a href="login.php" style="text-align : center">Please Login to Continue</a>
        </div><?php
        } ?>
</body>

</html>